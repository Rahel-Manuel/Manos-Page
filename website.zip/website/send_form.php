<?php
// send_form.php

// Empfänger-Adresse festlegen (hier: gwm809xd@gmail.com)
$empfaenger = "gwm809xd@gmail.com";

// Betreff der E-Mail
$betreff = "Neue Kontaktanfrage von der Website";

// Prüfen, ob das Formular per POST gesendet wurde
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Formularfelder sicher auslesen und bereinigen
    $name = strip_tags(trim($_POST["name"]));
    $email = filter_var(trim($_POST["email"]), FILTER_SANITIZE_EMAIL);
    $nachricht = trim($_POST["nachricht"]);

    // Überprüfen, ob alle Felder ausgefüllt sind und die E-Mail valide ist
    if (empty($name) || empty($email) || empty($nachricht) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        // Bei Fehler: Zurück zur Kontaktseite mit Fehlercode
        header("Location: kontakt.html?error=1");
        exit;
    }

    // Inhalt der E-Mail zusammenstellen (Zeilenumbrüche als "\r\n" für bessere Kompatibilität)
    $email_inhalt = "Name: $name\r\n";
    $email_inhalt .= "E-Mail: $email\r\n\r\n";
    $email_inhalt .= "Nachricht:\r\n$nachricht\r\n";

    // E-Mail-Header festlegen
    $email_header = "From: $name <$email>\r\n";

    // E-Mail versenden
    if (mail($empfaenger, $betreff, $email_inhalt, $email_header)) {
        // Erfolgreich gesendet – Weiterleitung zur Dankesseite
        header("Location: danke.html");
        exit;
    } else {
        // Versand fehlgeschlagen – Weiterleitung zurück zur Kontaktseite mit Fehlercode
        header("Location: kontakt.html?error=2");
        exit;
    }
} else {
    // Formular wurde nicht per POST gesendet – zurück zur Kontaktseite
    header("Location: kontakt.html");
    exit;
}
?>
